import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http'


import {FormControl,FormGroup} from "@angular/forms"
@Injectable({
  providedIn: 'root'
})
export class MyserviceService {
studata:any;
apn:any='';
frm= new FormGroup({
  name:new FormControl(),
  age:new FormControl(),
  email:new FormControl(),
  
  desg:new FormControl(),
});

  constructor(private http:HttpClient ) { }

  add_entry(){
    var name = this.frm.value.name;
    var age = this.frm.value.age;
    var email = this.frm.value.email;
    var desg = this.frm.value.desg;
    var url = "http://localhost:3000/createnew?name="+name+"&age="+age+"&email="+email+"&desg="+desg;
    this.http.get(url).subscribe(res=>{
      if(res){
        alert("Student Data saved");
        this.getalldata();
        this.clearme();
      }
    });
    console.log(this.frm.value);
  }
  getalldata(){
    console.log("heoo");
    var url ="http://localhost:3000/getallstudent";
    this.http.get(url).subscribe(res=>{
      this.studata =res;
      console.log(res);
    })
  }
  edit(id){
   
    var url = "http://localhost:3000/getsinglestudent?id="+id;
    this.http.get(url).subscribe(res=>{
      if(res){
        
        var ldata:any=res[0];
        this.apn=ldata._id;
        console.log(ldata);
        this.frm.setValue({
          name:ldata.name,
          age:ldata.age,
          email:ldata.email,
          desg:ldata.desg,
        })
      }
    });
  }
  update(id){
    var name = this.frm.value.name;
    var age = this.frm.value.age;
    var email = this.frm.value.email;
    var desg = this.frm.value.desg;
    var url = "http://localhost:3000/updatestudent?name="+name+"&age="+age+"&email="+email+"&desg="+desg+"&id="+this.apn;
    this.http.get(url).subscribe(res=>{
      if(res){
        alert("Student Data saved");
        this.getalldata();
        this.clearme();
  }
});
  }
  deletestu(id){
    var url = "http://localhost:3000/deletestudent?id="+id;
    this.http.get(url).subscribe(res=>{
      if(res){
        alert("Student Data Deleted");
        this.getalldata();
      }
    });
  }

clearme(){
  this.frm.setValue({
    name:'',
    age:'',
    email:'',
    desg:'',
  })
}

}
