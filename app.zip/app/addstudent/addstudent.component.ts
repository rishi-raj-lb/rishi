import { Component, OnInit } from '@angular/core';
import {FormGroup,FormsModule} from "@angular/forms"
import { MyserviceService } from '../myservice.service';
@Component({
  selector: 'app-addstudent',
  templateUrl: './addstudent.component.html',
  styleUrls: ['./addstudent.component.css']
})
export class AddstudentComponent implements OnInit {

  constructor(private ser:MyserviceService) {
    console.log("hello i am cons");
    this.ser.getalldata();
   }

  ngOnInit() {
  }
  save(){
    this.ser.add_entry();
  }
  delete(id){
    this.ser.deletestu(id);
    console.log("id = "+id);
  }
  
  update(id){
    
    this.ser.edit(id);
    
  }
}
